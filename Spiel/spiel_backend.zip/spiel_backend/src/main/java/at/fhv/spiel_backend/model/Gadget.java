package at.fhv.spiel_backend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
public class Gadget {
    private String id;
    private GadgetType type;
    private int remainingUses;
    private long timeRemaining;

    public Gadget(GadgetType type, String playerId) {
     id= playerId + "-" + UUID.randomUUID();
     this.type = type;
     timeRemaining = 0L;
     remainingUses = 3;
     System.out.println("[INFO] New Gadget: " + id);
    }
}
