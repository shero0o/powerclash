package at.fhv.spiel_backend.model;

public enum GadgetType {
    DAMAGE_BOOST,
    HEALTH_BOOST,
    SPEED_BOOST
}
