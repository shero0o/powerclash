package at.fhv.spiel_backend.model;

public enum ProjectileType {
    SNIPER, SHOTGUN_PELLET, RIFLE_BULLET, MINE
}
