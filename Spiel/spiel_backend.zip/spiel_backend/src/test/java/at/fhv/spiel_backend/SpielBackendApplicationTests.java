package at.fhv.spiel_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpielBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
